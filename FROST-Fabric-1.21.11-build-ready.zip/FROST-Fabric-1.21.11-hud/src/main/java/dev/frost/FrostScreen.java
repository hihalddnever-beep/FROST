package dev.frost;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class FrostScreen extends Screen {
    private static final int CYAN = 0xFF38C8FF;
    private static final int WHITE = 0xFFEAF8FF;
    private static final int MUTED = 0xFF82BBD7;
    private static final int GLASS = 0xD9091B2D;
    private static final int ROW = 0xC9163049;
    private int selectedTab = 0;
    private int selectedPalette = 0;
    private static final String[] PALETTE_NAMES = {"Ледяной голубой", "Фиолетовый", "Изумрудный", "Красный", "Белый"};
    private static final int[] PALETTE = {0xFF38C8FF, 0xFFAA78FF, 0xFF48E0B0, 0xFFFF5B70, 0xFFF1F7FF};
    private int accent() { return PALETTE[selectedPalette]; }

    private static final String[] TABS = {"Визуалы", "Утилиты", "HUD", "Цвета", "Прочее"};

    public FrostScreen() {
        super(Component.literal("FROST"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0x70030A13);

        int w = Math.min(890, width - 28);
        int h = Math.min(500, height - 28);
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        int r = x + w, b = y + h;

        // Layered translucent panels create a glass-like look without a shader.
        int accent = accent();
        g.fill(x - 1, y - 1, r + 1, b + 1, accent);
        g.fill(x, y, r, b, GLASS);
        g.fill(x + 1, y + 1, r - 1, y + 4, accent);
        g.fill(x + 18, y + 18, r - 18, y + 76, 0xA9143551);
        g.drawString(font, "◆  FROST", x + 26, y + 26, WHITE, false);
        g.drawString(font, "Визуальные настройки", x + 28, y + 48, MUTED, false);
        g.drawString(font, "×", r - 28, y + 27, CYAN, false);

        int sidebarX = x + 16;
        int sidebarY = y + 91;
        int sidebarW = Math.min(190, w / 4);
        for (int i = 0; i < TABS.length; i++) {
            int ry = sidebarY + i * 48;
            boolean active = selectedTab == i;
            g.fill(sidebarX, ry, sidebarX + sidebarW, ry + 40,
                    active ? 0xFF087CB8 : 0x9D102A40);
            if (active) g.fill(sidebarX, ry, sidebarX + 3, ry + 40, accent);
            g.drawString(font, TABS[i], sidebarX + 13, ry + 14, active ? WHITE : MUTED, false);
        }

        int contentX = sidebarX + sidebarW + 22;
        int contentRight = r - 22;
        int contentW = contentRight - contentX;
        g.fill(contentX - 10, sidebarY - 4, contentX - 9, b - 22, 0x7F1A7FA8);
        g.drawString(font, TABS[selectedTab], contentX + 5, sidebarY + 3, WHITE, false);
        g.drawString(font, "FROST  •  Только визуальные настройки", contentX + 5, sidebarY + 20, MUTED, false);

        if (selectedTab == 3) {
            int left = contentX + 5;
            int top = sidebarY + 56;
            g.drawString(font, "Цветовая схема", left, top, WHITE, false);
            g.drawString(font, "Нажми на цвет, чтобы применить его к акцентам", left, top + 18, MUTED, false);
            int cardW = Math.max(90, (contentW - 32) / 2);
            for (int i = 0; i < PALETTE.length; i++) {
                int xx = left + (i % 2) * (cardW + 12);
                int yy = top + 48 + (i / 2) * 58;
                g.fill(xx, yy, xx + cardW, yy + 48, i == selectedPalette ? 0xFF244E68 : ROW);
                g.fill(xx + 9, yy + 10, xx + 29, yy + 30, PALETTE[i]);
                g.drawString(font, PALETTE_NAMES[i], xx + 38, yy + 17, WHITE, false);
            }
            g.drawString(font, "Выбрано: " + PALETTE_NAMES[selectedPalette], left, top + 48 + 3 * 58, accent, false);
        } else {
        String[][] options = switch (selectedTab) {
            case 1 -> new String[][] {
                    {"Анимации интерфейса", "Плавные переходы"},
                    {"Прозрачные панели", "Стеклянный стиль"},
                    {"Уведомления", "Сообщения мода"},
                    {"Минималистичные элементы", "Чистый интерфейс"}
            };
            case 2 -> new String[][] {
                    {"Watermark FROST", "Логотип, ник, режим и FPS"},
                    {"Координаты", "X / Y / Z и направление"},
                    {"Пинг", "Задержка соединения, если доступна"},
                    {"Карточка игрока", "Скин, ник и здоровье"},
                    {"Эффекты", "Активные эффекты и время"},
                    {"Бинды", "Назначенные клавиши"},
                    {"Уведомления", "Сообщения и статус FROST"},
                    {"Музыкальный виджет", "Мини-панель проигрывателя"},
                    {"Индикатор слота", "Информация о выбранном слоте"},
                    {"Счётчик FPS", "Частота кадров в секунду"}
            };
            case 3 -> new String[][] {
                    {"Основной цвет", "Ледяной голубой"},
                    {"Вторичный цвет", "Глубокий синий"},
                    {"Свечение", "Мягкий неоновый акцент"},
                    {"Тема", "Тёмное стекло"}
            };
            case 4 -> new String[][] {
                    {"Клавиши", "Настройка открытия меню"},
                    {"Конфигурации", "Сохранение и загрузка настроек"},
                    {"Сброс настроек", "Вернуть стандартные параметры"},
                    {"Информация о моде", "FROST 0.1.0 · Fabric 1.21.11"}
            };
            default -> new String[][] {
                    {"Визуальный стиль", "Тёмное стекло"},
                    {"Меню на Right Shift", "Открыть или закрыть GUI"},
                    {"Анимации интерфейса", "Плавные переходы"},
                    {"Размытие фона", "Требует отдельного шейдера"}
            };
        };

        int rowX = contentX + 5;
        int rowW = Math.max(120, contentW - 10);
        int rowY = sidebarY + 56;
        int rowH = selectedTab == 2 ? 29 : 48;
        int rowGap = selectedTab == 2 ? 5 : 10;
        for (int i = 0; i < options.length; i++) {
            int yy = rowY + i * (rowH + rowGap);
            g.fill(rowX, yy, rowX + rowW, yy + rowH, ROW);
            g.fill(rowX, yy, rowX + 2, yy + rowH, accent());
            if (selectedTab == 2) {
                g.drawString(font, options[i][0], rowX + 9, yy + 3, WHITE, false);
                g.drawString(font, options[i][1], rowX + 9, yy + 15, MUTED, false);
                int sw = rowX + rowW - 28;
                g.fill(sw, yy + 7, sw + 18, yy + 22, 0xFF244A62);
                g.fill(sw + 2, yy + 9, sw + 9, yy + 20, accent());
            } else {
                g.drawString(font, options[i][0], rowX + 12, yy + 8, WHITE, false);
                g.drawString(font, options[i][1], rowX + 12, yy + 25, MUTED, false);
                if (selectedTab == 0 && i < 3) {
                    g.fill(rowX + rowW - 44, yy + 14, rowX + rowW - 10, yy + 34, 0xFF078DCB);
                    g.fill(rowX + rowW - 23, yy + 16, rowX + rowW - 12, yy + 32, 0xFFEAF8FF);
                }
            }
        }
        }

        // Preview column, keeping the overall composition close to the chosen concept.
        int previewW = Math.min(180, contentW / 3);
        int px = contentRight - previewW;
        int py = sidebarY + 5;
        g.fill(px, py, contentRight, py + 250, 0x9B0C2237);
        g.drawString(font, "Предпросмотр", px + 10, py + 10, WHITE, false);
        g.fill(px + 10, py + 34, contentRight - 10, py + 190, 0xFF102E47);
        g.drawString(font, "FROST", px + 20, py + 52, accent, false);
        g.drawString(font, "HUD  •  FPS", px + 20, py + 76, MUTED, false);
        g.drawString(font, "Визуальный стиль", px + 10, py + 204, MUTED, false);
        g.drawString(font, "Fabric 1.21.11", x + 24, b - 31, MUTED, false);
        g.drawString(font, "Right Shift  •  Закрыть", r - 175, b - 31, MUTED, false);

        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int w = Math.min(890, width - 28);
        int h = Math.min(500, height - 28);
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        int sidebarX = x + 16;
        int sidebarY = y + 91;
        int sidebarW = Math.min(190, w / 4);
        if (button == 0 && mouseX >= sidebarX && mouseX <= sidebarX + sidebarW) {
            for (int i = 0; i < TABS.length; i++) {
                int ry = sidebarY + i * 48;
                if (mouseY >= ry && mouseY <= ry + 40) {
                    selectedTab = i;
                    return true;
                }
            }
        }
        if (button == 0 && selectedTab == 3) {
            int contentX = sidebarX + sidebarW + 22;
            int contentW = (x + w - 22) - contentX;
            int left = contentX + 5;
            int top = sidebarY + 56 + 48;
            int cardW = Math.max(90, (contentW - 32) / 2);
            for (int i = 0; i < PALETTE.length; i++) {
                int xx = left + (i % 2) * (cardW + 12);
                int yy = top + (i / 2) * 58;
                if (mouseX >= xx && mouseX <= xx + cardW && mouseY >= yy && mouseY <= yy + 48) {
                    selectedPalette = i;
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 344) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
