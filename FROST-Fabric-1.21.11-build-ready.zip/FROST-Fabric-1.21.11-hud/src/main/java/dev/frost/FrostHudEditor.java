package dev.frost;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import java.util.ArrayList;
import java.util.List;

/** HUD editor. All widgets are visible while chat is open so they can be positioned. */
public final class FrostHudEditor {
    private FrostHudEditor() {}
    private static final int CYAN = 0xFF38C8FF;
    private static final int PANEL = 0xD9091B2D;
    private static boolean showFps = true;
    private static boolean showPing = true;
    private static boolean showWatermark = true;
    private static boolean settingsOpen = false;
    private static Widget settingsOwner;
    private static final Widget WATERMARK = new Widget("◆ FROST  •  Visual", 14, 26, 150, 22, "watermark");
    private static final Widget COORDS = new Widget("XYZ  120 / 64 / -38", 14, 56, 170, 22, "coords");
    private static final Widget PERF = new Widget("FPS  144  •  Ping  32ms", 14, 86, 190, 22, "performance");
    private static final Widget BINDS = new Widget("Бинды  •  активные клавиши", 14, 116, 190, 22, "binds");
    private static final Widget TARGET = new Widget("Target HUD  •  игрок рядом", 14, 146, 200, 22, "target");
    private static final Widget POTIONS = new Widget("Potions  •  эффекты", 14, 176, 170, 22, "potions");
    private static final Widget[] WIDGETS = { WATERMARK, COORDS, PERF, BINDS, TARGET, POTIONS };
    private static Widget dragging;
    private static double grabX, grabY;

    public static void render(GuiGraphics g, int mouseX, int mouseY) {
        Minecraft mc = Minecraft.getInstance();
        if (!(mc.screen instanceof net.minecraft.client.gui.screens.ChatScreen)) return;
        g.drawString(mc.font, "FROST HUD EDITOR  •  ЛКМ — двигать, ПКМ по Watermark — настройки", 14, 8, CYAN, false);
        for (Widget w : WIDGETS) {
            boolean show = true; // editor shows every widget for easy positioning, regardless of in-game visibility
            if (!show) continue;
            g.fill(w.x - 1, w.y - 1, w.x + w.width + 1, w.y + w.height + 1, CYAN);
            g.fill(w.x, w.y, w.x + w.width, w.y + w.height, PANEL);
            String label = w.label;
            if (w.id.equals("performance")) label = "FPS " + (showFps ? "✓" : "×") + "  •  Ping " + (showPing ? "✓" : "×") + "  (ПКМ настройки на Watermark)";
            g.drawString(mc.font, label, w.x + 6, w.y + 7, 0xFFEAF8FF, false);
        }
        if (settingsOpen && settingsOwner != null) {
            int x = settingsOwner.x + settingsOwner.width + 8, y = settingsOwner.y;
            g.fill(x - 1, y - 1, x + 154, y + 70, CYAN);
            g.fill(x, y, x + 152, y + 68, PANEL);
            g.drawString(mc.font, "WATERMARK SETTINGS", x + 6, y + 6, CYAN, false);
            g.drawString(mc.font, "FPS: " + (showFps ? "ON" : "OFF") + "  (ЛКМ)", x + 6, y + 25, 0xFFEAF8FF, false);
            g.drawString(mc.font, "Ping: " + (showPing ? "ON" : "OFF") + "  (ЛКМ)", x + 6, y + 43, 0xFFEAF8FF, false);
        }
    }

    public static boolean mouseClicked(double x, double y, int button) {
        Minecraft mc = Minecraft.getInstance();
        if (settingsOpen && settingsOwner != null) {
            int sx = settingsOwner.x + settingsOwner.width + 8, sy = settingsOwner.y;
            if (x >= sx && x <= sx + 152 && y >= sy + 20 && y <= sy + 39) { showFps = !showFps; return true; }
            if (x >= sx && x <= sx + 152 && y >= sy + 39 && y <= sy + 58) { showPing = !showPing; return true; }
            if (button == 0 && (x < sx || x > sx + 152 || y < sy || y > sy + 68)) settingsOpen = false;
        }
        for (int i = WIDGETS.length - 1; i >= 0; i--) {
            Widget w = WIDGETS[i];
            if (x >= w.x && x <= w.x + w.width && y >= w.y && y <= w.y + w.height) {
                if (button == 1 && w.id.equals("watermark")) { settingsOwner = w; settingsOpen = !settingsOpen; return true; }
                if (button != 0) return false;
                dragging = w; grabX = x - w.x; grabY = y - w.y; return true;
            }
        }
        return false;
    }
    public static boolean mouseDragged(double x, double y, int button) {
        if (dragging == null || button != 0) return false;
        Minecraft mc = Minecraft.getInstance();
        dragging.x = clamp((int)(x - grabX), 0, Math.max(0, mc.getWindow().getGuiScaledWidth() - dragging.width));
        dragging.y = clamp((int)(y - grabY), 18, Math.max(18, mc.getWindow().getGuiScaledHeight() - dragging.height));
        return true;
    }
    public static boolean mouseReleased(int button) {
        if (button == 0 && dragging != null) { dragging = null; return true; }
        return false;
    }
    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    private static final class Widget {
        final String label, id; final int width, height; int x, y;
        Widget(String label, int x, int y, int width, int height, String id) {
            this.label = label; this.x = x; this.y = y; this.width = width; this.height = height; this.id = id;
        }
    }
}
