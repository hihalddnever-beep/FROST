package dev.frost.mixin;

import dev.frost.FrostHudEditor;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ChatScreen.class)
public abstract class ChatScreenMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void frost$renderHudEditor(GuiGraphics graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        FrostHudEditor.render(graphics, mouseX, mouseY);
    }
    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void frost$clickHud(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (FrostHudEditor.mouseClicked(mouseX, mouseY, button)) cir.setReturnValue(true);
    }
    @Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true)
    private void frost$dragHud(double mouseX, double mouseY, int button, double dragX, double dragY, CallbackInfoReturnable<Boolean> cir) {
        if (FrostHudEditor.mouseDragged(mouseX, mouseY, button)) cir.setReturnValue(true);
    }
    @Inject(method = "mouseReleased", at = @At("HEAD"), cancellable = true)
    private void frost$releaseHud(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (FrostHudEditor.mouseReleased(button)) cir.setReturnValue(true);
    }
}
