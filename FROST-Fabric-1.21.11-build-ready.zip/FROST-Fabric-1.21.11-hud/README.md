# FROST — Fabric 1.21.11

Client-side visual interface prototype for Minecraft 1.21.11 / Fabric / Java 21.

## Build a test JAR automatically

This repository includes a GitHub Actions workflow (`.github/workflows/build.yml`) that compiles the project and publishes the JAR as an artifact.

1. Create a new repository on GitHub.
2. Upload the contents of this folder (not the ZIP file itself) to the repository's `main` branch.
3. Open the repository's **Actions** tab and select **Build FROST**.
4. Press **Run workflow** if it has not started automatically.
5. Open the completed workflow run and download the **FROST-Fabric-1.21.11** artifact. Extract the downloaded artifact ZIP to get the mod JAR.
6. Put the JAR in the `mods` folder alongside Fabric API and Fabric Loader for Minecraft 1.21.11.

This workflow builds the source; it does not certify runtime compatibility. Test in a separate instance first and keep a copy of your world.

## Current prototype

- Right Shift opens/closes the FROST menu.
- Palette selection changes the accent color in the menu.
- HUD editor widgets can be dragged while the chat screen is open.

Some menu rows are currently visual mock controls and do not yet enable real in-game features. This is a client-side visual prototype, not a complete production mod.
